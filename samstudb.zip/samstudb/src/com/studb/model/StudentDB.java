package com.studb.model;

public class StudentDB {

	private String Name;
	private String Father_name;
	private String Address;
	private String District;
	private int Pincode;
	private String DOB;
	private String Gender;
	private String Mobileno; 
	private String Department;
	private String UG_REGNO;
	private String Emailid;
	private String Board;
	private String Medium;
	private int SSLC_mark;
	private String School_name;
	private String H_Board;
	private String Medium1;
	private String Subject1;
	private String Subject2;
	private String Subject3;
	private String Subject4;
	private int Mark;
	private String HSS_Name;
	private String Degree;
	private String Branch;
	private String College;
	private String PG_Degree;
	private String PG_Branch;
	private String PGDepartment;
	private String PG_REGNO;
	private String PGCollege;
	private String Password;
	private int Status;
	
	public String getName() {
		return Name;
	}
	
	public String getFather_name() {
		return Father_name;
	}
	
	public String getAddress() {
		return Address;
	}
	
	public String getDistrict(){
		return District;
	}
	public int getPincode(){
		return Pincode;
	}
	
	public String getDOB(){
		return DOB;
	}
	
	public String getGender(){
		return Gender;
	}
	
	public String getMobileno(){
		return Mobileno;
	}
	
	public String getDepartment(){
		return Department ;
	}
	
	public String getUG_REGNO(){
		return UG_REGNO;
	}
	
	public String getEmailid(){
		return Emailid;
	}
	
	public String getBoard(){
		return Board;
	}
	public String getMedium(){
		return Medium;
	}
	public int getSSLC_mark(){
		return SSLC_mark;
	}
	
	public String getSchool_name(){
		return School_name;
	}
	
	public String getH_Board(){
		return H_Board;
	}
	
	public String getMedium1(){
		return Medium1;
	}
	
	public String getSubject1(){
		return Subject1;
	}
	
	public String getSubject2(){
		return Subject2;
	}
	
	public String getSubject3(){
		return Subject3;
	}
	
	public String getSubject4(){
		return Subject4;
	}
	
	public int getMark(){
		return Mark;
	}
	
	public String getHSS_Name(){
		return HSS_Name;
	}
	public String getDegree(){
		return Degree;
	}
	
	public String getBranch(){
		return Branch;
	}
	
	public String getCollege(){
		return College;
	}
	
	public String getPG_Degree(){
	return PG_Degree;
	}
	
	public String getPG_Branch(){
		return PG_Branch;
	}
	
	public String getPGDepartment(){
		return PGDepartment;
	}
	
	public String getPG_REGNO(){
		return PG_REGNO;
	}
	
	public String getPGCollege(){
		return PGCollege;
	}
	
	public String getPassword(){
		return Password;
	}
	public int getStatus(){
		return Status;
	}
	
	
	public void setname(String Name){
		this.Name=Name;
	}
	
	public void setfather_name(String Father_name){
		this.Father_name = Father_name;
	}
	
	public void setaddress(String Address){
		this.Address=Address;
	}
	
	public void setdistrict(String District){
		this.District=District;
	}
	
	public void setpincode(int Pincode){
		this.Pincode=Pincode;
	}
	
	public void setdob(String DOB){
		this.DOB=DOB;
	}
	
	public void setgender(String Gender){
		this.Gender=Gender;
	}
	
	public void setmobileno(String Mobileno){
		this.Mobileno=Mobileno;
	}
	
	public void setdepartment(String Department){
		this.Department=Department;
	}
	
	public void setug_regno(String UG_REGNO){
		this.UG_REGNO=UG_REGNO;
	}
	
	public void setemialid(String Emailid){
		this.Emailid=Emailid;
	}
	
	public void setboard(String Board){
		this.Board=Board;
	}
	
	public void setmedium(String Medium){
		this.Medium=Medium;
	}
	
	public void setsslc_mark(int SSLC_mark){
		this.SSLC_mark=SSLC_mark;
	}
	
	public void setschool_name(String School_name){
		this.School_name=School_name;
	}
	
	public void seth_board(String H_Board){
		this.H_Board=H_Board;
	}
	
	public void setmedium1(String Medium1){
		this.Medium1=Medium1;
	}
	
	public void setsubject1(String Subject1){
		this.Subject1=Subject1;
	}
	
	public void setsubject2(String Subject2){
		this.Subject2=Subject2;
	}
	
	public void setsubject3(String Subject3){
		this.Subject3=Subject3;
	}
	
	public void setsubject4(String Subject4){
		this.Subject4=Subject4;
	}
	
	public void setmark(int Mark){
		this.Mark=Mark;
	}
	
	public void sethss_name(String HSS_Name){
		this.HSS_Name=HSS_Name;
	}
	
	public void setdegree(String Degree){
		this.Degree=Degree;
	}
	
	public void setbranch(String Branch){
		this.Branch=Branch;
	}
	
	public void setcollege(String College){
		this.College=College;
	}
	
	public void setpg_degree(String PG_Degree){
		this.PG_Degree=PG_Degree;
	}
	
	public void setpg_branch(String PG_Branch){
		this.PG_Branch=PG_Branch;
			}
	
	public void setpgdepartment(String PGDepartment){
		this.PGDepartment=PGDepartment;
			}
	
	public void setpg_regno(String PG_REGNO){
		this.PG_REGNO=PG_REGNO;
	}
	
	public void setpgcollege(String PGCollege){
		this.PGCollege=PGCollege;
	}
	
	public void setpassword(String Password){
		this.Password=Password;
	}

	public void setstatus(int Status) {
		this.Status=Status;
		
	}
}
