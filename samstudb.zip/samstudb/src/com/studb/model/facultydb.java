package com.studb.model;

public class facultydb {
	private String Name;
	private String Emilid;
	private String Password;
	private String Department;
	private String Gender;
	private String Mobileno;
	private String Edu_qua;
	private String CLass_advisor;
	

}
