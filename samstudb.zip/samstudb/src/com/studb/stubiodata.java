package com.studb;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class stubiodata
 */
@WebServlet("/stubiodata")
public class stubiodata extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Connection con=db.getCon();
			Statement stmt= con.createStatement();
			System.out.println(request.getParameter("Name"));
						int result=stmt.executeUpdate("insert into facultyreg(Name,Emailid,Password,Department,Gender,Mobileno,Edu_qua,Class_advisor,dept,year,section) values('"+request.getParameter("Name")+"','"+request.getParameter("Emailid")+"','"+request.getParameter("Password")+"','"+request.getParameter("Department")+"','"+request.getParameter("Gender")+"','"+request.getParameter("Mobileno")+"','"+request.getParameter("Edu_qua")+"','"+request.getParameter("Class_advisor")+"','"+request.getParameter("dept")+"','"+request.getParameter("year")+"','"+request.getParameter("section")+"')");
						
						if (result == 1)
						{
							request.getRequestDispatcher("faculty.html").include(request, response);
													}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
	}

}
