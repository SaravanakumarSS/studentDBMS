package com.studb;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

/**
 * Servlet implementation class facultyjoin
 */
@WebServlet("/facultyjoin")
public class facultyjoin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			Connection con=db.getCon();
			Statement stmt= con.createStatement();
			//System.out.println(request.getParameter("Name"));
			int result=stmt.executeUpdate("insert into facultyreg(Name,Emailid,Password,Department) values('"+request.getParameter("Name")+"','"+request.getParameter("Emailid")+"','"+request.getParameter("Password")+"','"+request.getParameter("Department")+"')");
			
			if (result == 1)
{
	sendMail.send("kgislsaravanan@gmail.com","boeing787",request.getParameter("Emailid"),"Welcome Email","User details have been registered in our store. you can use this details for furthur login\n"+"Name :"+request.getParameter("Name")+"\nEmail ID:"+request.getParameter("Emailid")+"\nPassword:"+request.getParameter("Password")+"\nDeparment:"+request.getParameter("Department"));	
	request.getRequestDispatcher("facadmin.html").include(request, response);
}
con.close();	

			
		} catch (Exception e) {
			System.out.println(e); 
			// TODO: handle exception
		}// TODO Auto-generated method stub
	}
	
	

}
