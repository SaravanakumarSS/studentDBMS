package com.studb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.studb.model.StudentDB;

/**
 * Servlet implementation class controller
 */
@WebServlet("/controller")
public class controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();

	private updatestu dao;

    public controller() {
		dao = new updatestu();
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @param Father_name 
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		List<StudentDB> studentList = new ArrayList<StudentDB>();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.setContentType("application/json");

		
		if (action != null) {
			try {
				if (action.equals("create") || action.equals("update")) {
				}
						StudentDB student = new StudentDB();
						if (request.getParameter("Emailid") != null) {
							String Emailid = request.getParameter("Emailid");
							//int Emailid = Integer.parseInt(request.getParameter("Emailid"));
							student.setemialid(Emailid);
			doGet(request, response);
		}
						if (request.getParameter("Father_name") != null) {
							String Father_name = request.getParameter("Father_name");
							student.setfather_name(Father_name);
						}
				
						if (request.getParameter("Address") != null) {
							String Address = request.getParameter("Address");
							student.setaddress(Address);
						}
						if (request.getParameter("District") != null) {
							String District = request.getParameter("District");
							student.setdistrict(District);
						}
						if (request.getParameter("Pincode") != null) {
							int Pincode = Integer.parseInt("Pincode");
							student.setpincode(Pincode);
						}
						if (request.getParameter("DOB") != null) {
							String DOB = request.getParameter("DOB");
							student.setdob(DOB);
						}
						if (request.getParameter("Gender") != null) {
							String Gender = request.getParameter("Gender");
							student.setgender(Gender);
						}
						if (request.getParameter("Mobileno") != null) {
							String Mobileno = request.getParameter("Mobileno");
							student.setmobileno(Mobileno);
						}
						if (request.getParameter("Department") != null) {
							String Department = request.getParameter("Department");
							student.setdepartment(Department);
						}
						if (request.getParameter("UG_REGNO") != null) {
							String UG_REGNO = request.getParameter("UG_REGNO");
							student.setdepartment(UG_REGNO);
						}
						if (request.getParameter("Board") != null) {
							String Board = request.getParameter("Board");
							student.setboard(Board);
						}
						if (request.getParameter("Medium") != null) {
							String Medium = request.getParameter("Medium");
							student.setmedium(Medium);
						}
						if (request.getParameter("SSLC_mark") != null) {
							int SSLC_mark = Integer.parseInt("SSLC_mark");
							student.setsslc_mark(SSLC_mark);
						}
						if (request.getParameter("School_name") != null) {
							String School_name = request.getParameter("School_name");
							student.setschool_name(School_name);
						}
						if (request.getParameter("H_Board") != null) {
							String H_Board = request.getParameter("H_Board");
							student.seth_board(H_Board);
						}
						if (request.getParameter("Medium") != null) {
							String Medium = request.getParameter("Medium");
							student.setmedium(Medium);
						}
						if (request.getParameter("Subject1") != null) {
							String Subject1 = request.getParameter("Subject1");
							student.setsubject1(Subject1);
						}
						if (request.getParameter("Subject2") != null) {
							String Subject2 = request.getParameter("Subject2");
							student.setsubject2(Subject2);
						}
						if (request.getParameter("Subject3") != null) {
							String Subject3 = request.getParameter("Subject3");
							student.setsubject3(Subject3);
						}
						if (request.getParameter("Subject4") != null) {
							String Subject4 = request.getParameter("Subject4");
							student.setsubject4(Subject4);
						}
						
						if (request.getParameter("Mark") != null) {
							int Mark = Integer.parseInt("Mark");
							student.setmark(Mark);
						}
						
						if (request.getParameter("HSS_Name") != null) {
							String HSS_Name = request.getParameter("HSS_Name");
							student.sethss_name(HSS_Name);
						}

						
						if (request.getParameter("Degree") != null) {
							String Degree = request.getParameter("Degree");
							student.setdegree(Degree);
						}
						if (request.getParameter("Branch") != null) {
							String Branch = request.getParameter("Branch");
							student.setbranch(Branch);
						}
						if (request.getParameter("College") != null) {
							String College = request.getParameter("College");
							student.setcollege(College);
						}
						if (request.getParameter("PG_Degree") != null) {
							String PG_Degree = request.getParameter("PG_Degree");
							student.setpg_degree(PG_Degree);
						}
						if (request.getParameter("PG_Branch") != null) {
							String PG_Branch = request.getParameter("PG_Branch");
							student.setpg_branch(PG_Branch);
						}
						if (request.getParameter("PGDepartment") != null) {
							String PGDepartment = request.getParameter("PGDepartment");
							student.setpgdepartment(PGDepartment);
						}
						if (request.getParameter("PG_REGNO") != null) {
							String PG_REGNO = request.getParameter("PG_REGNO");
							student.setpg_regno(PG_REGNO);
						}
						if (request.getParameter("PGCollege") != null) {
							String PGCollege = request.getParameter("PGCollege");
							student.setpgcollege(PGCollege);
						}
						if (request.getParameter("Password") != null) {
							String Password = request.getParameter("Password");
							student.setpassword(Password);
						}
						
						if (action.equals("update")) {
							// Update existing record
							dao.updatestu(student);
						}		
						// Return in the format required by jTable plugin
						JSONROOT.put("Result", "OK");
						JSONROOT.put("Record", student);

						// Convert Java Object to Json
						String jsonArray = gson.toJson(JSONROOT);
						response.getWriter().print(jsonArray);
					} 
		
	
				
			 catch (Exception e) {
				 JSONROOT.put("Result", "ERROR");
					JSONROOT.put("Message", e.getMessage());
					String error = gson.toJson(JSONROOT);
					response.getWriter().print(error);
			} 
		}
		}
}
				