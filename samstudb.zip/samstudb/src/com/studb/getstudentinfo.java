package com.studb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.studb.model.StudentDB;

/**
 * Servlet implementation class getstudentinfo
 */
@WebServlet("/getstudentinfo")
public class getstudentinfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String studentid = request.getParameter("studentid");
		int stuid=Integer.parseInt(studentid);
		List<StudentDB> studentList = new ArrayList<StudentDB>();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.setContentType("application/json");
		if (studentid != null) {
			try {
				studentList=Studentdao.getstudentinfo(stuid);
				JSONROOT.put("Result", "OK");
				JSONROOT.put("Records", studentList);

				// Convert Java Object to Json
				String jsonArray = gson.toJson(JSONROOT);

				response.getWriter().print(jsonArray);
				
			}catch(Exception e){
				System.out.println(e);}
			}
		
	}

}
