package com.studb;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class joinus
 */
@WebServlet("/joinus")
public class joinus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String dbEmailid = null;
	String dbPassword = null;
	String mailstr = null;
	String passstr = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		
   		try{
   			mailstr=request.getParameter("Emailid");
   			passstr=request.getParameter("Password");
   			 response.setContentType("text/html");
   			Connection con=db.getCon();
   			
   			if(mailstr.equalsIgnoreCase("admin@gmail.com") && passstr.equalsIgnoreCase("admin")){
   			 request.getRequestDispatcher("facadmin.html").include(request, response);
   			}
   			
   			else{
   				System.out.println(mailstr+"\n"+passstr);
   				Statement stmt=con.createStatement();
   	   			
   	   			
   	   			ResultSet rs = stmt.executeQuery("select ID,Emailid,Password,work from addstu where Emailid='"+mailstr+"' and Password='"+passstr+"'");
   	   			System.out.println("select ID,Emailid,Password,work from addstu where Emailid='"+mailstr+"' and Password='"+passstr+"'");
   	   			String res=null;
   				int id=0;
   				int work=0;
   				
   	   		
   	   		if(!rs.next()){
   	   		
   	   			stmt=con.createStatement();
	   			rs = stmt.executeQuery("select ID,Emailid,Password,work from facultyreg");
   	   		}
   	   		System.out.println(rs.next());
   	   			
   				while(rs.next())
   			{
   	         dbEmailid = rs.getString("Emailid");
   	         dbPassword = rs.getString("Password");
   	         id=rs.getInt("ID");
   	         work=rs.getInt("work");
   	         
   	       if(dbEmailid.equals(mailstr) && dbPassword.equals(passstr))
   	    {
   	   	    res="success";
   	        }
   		}
   				
   			if(res.equalsIgnoreCase("success") && work==2)
   	       {
   				System.out.println(res);
   				PrintWriter out=response.getWriter();
   				out.write("<span style='color:red;display:none' class='studentid'>"+id+"</span>");
   	   	    request.getRequestDispatcher("stuinfo.html").include(request, response);
   	        }
   	      else if(res.equalsIgnoreCase("success") && work==1)
   	      {
   	    	System.out.println(res);
   	   	    request.getRequestDispatcher("fachome.html").include(request, response);
   	        //request.getRequestDispatcher("error.html").include(request, response);
   			  }
   		
   	      else
   	      {
   	        request.getRequestDispatcher("error.html").include(request, response);
   			  }
   			
   			}
   			
   			   	     
   			con.close();
   	  } 
   	  catch (Exception e) 
   		{
   		  System.out.println(e);
   		  }
	}

}
