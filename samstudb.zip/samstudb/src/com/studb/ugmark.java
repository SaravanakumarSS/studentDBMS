package com.studb;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.studb.model.StudentDB;

/**
 * Servlet implementation class ugmark
 */
@WebServlet("/ugmark")
public class ugmark extends HttpServlet {
	private static final long serialVersionUID = 1L;
       public ugmark() {
    	super();
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Connection con = db.getCon();
			Statement stmt= con.createStatement();
			//System.out.println(request.getParameter("Name"));
			int result=stmt.executeUpdate("insert into ugmark(UG_REGNO,Name,Department,Semester,S1,S2,S3,S4,S5,S6,S7,P1,P2,P3) values('"+request.getParameter("UG_REGNO")+"','"+request.getParameter("Name")+"','"+request.getParameter("Department")+"','"+request.getParameter("Semester")+"','"+request.getParameter("S1")+"','"+request.getParameter("S2")+"','"+request.getParameter("S3")+"','"+request.getParameter("S4")+"','"+request.getParameter("S5")+"','"+request.getParameter("S6")+"','"+request.getParameter("S7")+"','"+request.getParameter("P1")+"''"+request.getParameter("P2")+"','"+request.getParameter("P3")+"')");
			if (result == 1)
			{
				request.getRequestDispatcher("ugmark.html").include(request, response);
			}
			
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
	}
}




