package com.studb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.studb.model.StudentDB;

public class Studentdao {

	
	public static List<StudentDB> getstudentinfo(int studentid){
		
		List<StudentDB> student=new ArrayList<StudentDB>();
		try {
			Connection con=db.getCon();
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select *from addstu where ID="+studentid);
			while(rs.next())
			{
				StudentDB studentdb=new StudentDB();
				studentdb.setemialid(rs.getString("Emailid"));
				studentdb.setname(rs.getString("Name"));
				studentdb.setfather_name(rs.getString("Father_name"));
				studentdb.setaddress(rs.getString("Address"));
				studentdb.setdistrict(rs.getString("District"));
				studentdb.setpincode(rs.getInt("Pincode"));
				studentdb.setdob(rs.getString("DOB"));
				studentdb.setgender(rs.getString("Gender"));
				studentdb.setmobileno(rs.getString("Mobileno"));
				studentdb.setdepartment(rs.getString("Department"));
				studentdb.setug_regno(rs.getString("UG_REGNO"));
				studentdb.setboard(rs.getString("Board"));
				studentdb.setmedium(rs.getString("Medium"));
				studentdb.setsslc_mark(rs.getInt("SSLC_mark"));
				studentdb.setschool_name(rs.getString("School_name"));
				studentdb.seth_board(rs.getString("H_Board"));
				studentdb.setmedium1(rs.getString("Medium1"));
				studentdb.setsubject1(rs.getString("Subject1"));
				studentdb.setsubject2(rs.getString("Subject2"));
				studentdb.setsubject3(rs.getString("Subject3"));
				studentdb.setsubject4(rs.getString("Subject4"));
				studentdb.setmark(rs.getInt("Mark"));
				studentdb.sethss_name(rs.getString("HSS_Name"));
				studentdb.setdegree(rs.getString("Degree"));
				studentdb.setbranch(rs.getString("Branch"));
				studentdb.setcollege(rs.getString("College"));
				studentdb.setpg_degree(rs.getString("PG_Degree"));
				studentdb.setpg_branch(rs.getString("PG_Branch"));
				studentdb.setpgdepartment(rs.getString("PGDepartment"));
				studentdb.setpg_regno(rs.getString("PG_REGNO"));
				studentdb.setpgcollege(rs.getString("PGCollege"));
				studentdb.setpassword(rs.getString("Password"));
				studentdb.setstatus(rs.getInt("Status"));
				student.add(studentdb);
			}
			
			
			
			con.close();
		} catch (Exception e) {
			System.out.println("studentdao  " +e );
		}
		
		return student;
		
	}
}
