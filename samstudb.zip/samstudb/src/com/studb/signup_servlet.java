package com.studb;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class studentdb
 */
@WebServlet("/studentdb")
public class signup_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			Connection con=db.getCon();
			Statement stmt= con.createStatement();
			System.out.println(request.getParameter("Name"));
						int result=stmt.executeUpdate("insert into studb(Name,Emailid,Password,Conform_pwd,DOB,Gender,Mobileno) values('"+request.getParameter("Name")+"','"+request.getParameter("Emailid")+"','"+request.getParameter("Password")+"','"+request.getParameter("Conform_pwd")+"','"+request.getParameter("DOB")+"','"+request.getParameter("Gender")+"','"+request.getParameter("Mobileno")+"')");
						
						if (result == 1)
			{
				request.getRequestDispatcher("index.html").include(request, response);
			}
			con.close();	
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	}


