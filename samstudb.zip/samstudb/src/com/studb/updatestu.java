package com.studb;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.studb.model.StudentDB;



/**
 * Servlet implementation class updatestu
 */
@WebServlet("/updatestu")
public class updatestu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private Connection dbConnection;
	private PreparedStatement pStmt;
	private StudentDB student=new StudentDB();
    public updatestu() {
    	Connection con = db.getCon();
    	//super();
            }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			
				String updateQuery = "UPDATE addstu SET Father_name = ?,Address= ?, District=?,Pincode=?,DOB=?,Gender=?,Mobileno=?,UG_REGNO=?,Board=?,Medium=?,"
						+ "SSLC_mark=?,School_name=?,H_Board=?,Medium1=?,Subject1=?,Subject2=?,subject3=?,Subject4=?,Mark=?,Degree=?,Branch=?,College=?,"
						+ "PG_Degree=?,PG_Branch=?,PGDepartment=?,PG_REGNO=?,PGCollege=?,Password=?,HSS_Name=?,Status=?  WHERE Emailid = ?";
				try {
					dbConnection=db.getCon();	
					pStmt=dbConnection.prepareStatement(updateQuery);
					System.out.println(request.getParameter("Father_name"));
					pStmt.setString(1, request.getParameter("Father_name"));
					pStmt.setString(2,request.getParameter("Address"));
					pStmt.setString(3,request.getParameter("District"));
					pStmt.setInt(4, Integer.parseInt(request.getParameter("Pincode")));
					pStmt.setString(5,request.getParameter("DOB"));
					pStmt.setString(6,request.getParameter("Gender"));
					pStmt.setString(7, request.getParameter("Mobileno"));
					pStmt.setString(8,request.getParameter("UG_REGNO"));
					pStmt.setString(9,request.getParameter("Board"));
					pStmt.setString(10,request.getParameter("Medium"));
					pStmt.setInt(11,Integer.parseInt(request.getParameter("SSLC_mark")));
					pStmt.setString(12,request.getParameter("School_name"));
					pStmt.setString(13,request.getParameter("H_Board"));
					pStmt.setString(14,request.getParameter("Medium1"));
					pStmt.setString(15,request.getParameter("Subject1"));
					pStmt.setString(16,request.getParameter("Subject2"));
					pStmt.setString(17,request.getParameter("Subject3"));
					pStmt.setString(18,request.getParameter("Subject4"));
					pStmt.setInt(19,Integer.parseInt(request.getParameter("Mark")));
					pStmt.setString(20,request.getParameter("Degree"));
					pStmt.setString(21,request.getParameter("Branch"));
					pStmt.setString(22,request.getParameter("College"));
					pStmt.setString(23,request.getParameter("PG_Degree"));
					pStmt.setString(24,request.getParameter("PG_Branch"));
					pStmt.setString(25,request.getParameter("PGDepartment"));
					pStmt.setString(26,request.getParameter("PG_REGNO"));
					pStmt.setString(27,request.getParameter("PGCollege"));
					pStmt.setString(28,request.getParameter("Password"));
					pStmt.setString(29, request.getParameter("HSS_Name"));
					pStmt.setInt(30,1);
					pStmt.setString(31,request.getParameter("Emailid"));
					System.out.println(pStmt.executeUpdate());
					request.getRequestDispatcher("stureg.html").include(request, response);

				} 
				
					 catch (Exception e) {
			System.err.println(e.getMessage());// TODO: handle exception
		}// TODO Auto-generated method stub
			}
			
			
		

	public void updatestu(StudentDB student2) {
		// TODO Auto-generated method stub
		
	}
	
		
		
}
		
	
		
	

